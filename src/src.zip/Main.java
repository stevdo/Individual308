import View.homegui;


public class Main {

	public static void main(String[] args) {
		homegui h = new homegui();
		h.initialize();}
	

}
